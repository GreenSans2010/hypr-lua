hl.config({
    general = {
        gaps_in = 5,
        gaps_out = 5,
        border_size = 2,

        col = {
            -- Бирюзовый градиент активного окна
            active_border = {
                colors = {
                    "rgba(cbd5d1ee)",
                    "rgba(6c797bee)",
                },
                angle = 45,
            },

            -- Темная сине-бирюзовая рамка неактивных окон
            inactive_border = "rgba(4a5658aa)",
        },

        resize_on_border = false,
        allow_tearing = false,
        layout = "dwindle",
    },

    decoration = {
        rounding = 20,
        rounding_power = 1,

        active_opacity = 1.0,
        inactive_opacity = 1.0,

        shadow = {
            enabled = true,
            range = 2,
            render_power = 1000,

            -- Глубокая темно-бирюзовая тень
            color = "rgba(9ba6a3ee)",
        },

        blur = {
            enabled = true,
            size = 3,
            passes = 1,
            vibrancy = 0.1696,
        },
    },
})

hl.config({
    input = {
        kb_layout  = "us, ru",
        kb_variant = "",
        kb_model   = "",
        kb_options = "grp:alt_shift_toggle",
        kb_rules   = "",
        follow_mouse = 1,
        sensitivity = 0,
        touchpad = { natural_scroll = false },
    },
})

hl.gesture({
    fingers = 3,
    direction = "horizontal",
    action = "workspace"
})



-- Пример per‑device (раскомментируйте при необходимости)
-- hl.device({
--     name        = "epic-mouse-v1",
--     sensitivity = -0.5,
-- })

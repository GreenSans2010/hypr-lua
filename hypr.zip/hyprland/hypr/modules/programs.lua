-- Определяем программы, используемые в привязках
_G.my_programs = {
    terminal    = "kitty",
    fileManager = "caja",
    menu        = "rofi -show drun",
}

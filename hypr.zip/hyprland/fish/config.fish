if status is-interactive
    set -g fish_greeting ""
    nitch
    alias gs="git status"
    alias cat="bat"
    alias ls="lsd"
    alias lt="tree"
    # Commands to run in interactive sessions can go here
end
